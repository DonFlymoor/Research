var searchData=
[
  ['g',['g',['../classcolor.html#aee30bc30855695b3baf97597387f13f5',1,'color']]],
  ['gravity',['gravity',['../class_settings.html#a109205d134056c2e19a9c3396e5e975c',1,'Settings']]]
];
