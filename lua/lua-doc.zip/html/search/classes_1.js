var searchData=
[
  ['color',['color',['../classcolor.html',1,'']]]
];
