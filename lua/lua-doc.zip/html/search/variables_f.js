var searchData=
[
  ['torque',['torque',['../classwheel_data.html#afca88ac84b51f6c17dc1924f76676d09',1,'wheelData']]],
  ['total_5fweight',['total_weight',['../classbeamstats.html#a9f632ff45a33a38e3c082b39e17eca4a',1,'beamstats']]],
  ['translation',['translation',['../class_prop.html#a912908256597441d332806c3e7e2f8f0',1,'Prop']]]
];
