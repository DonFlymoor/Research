var searchData=
[
  ['makeanisotropic',['makeAnisotropic',['../classbeam.html#a006d07aafe4e9d0ce6acc646cbb951d5',1,'beam']]],
  ['makebounded',['makeBounded',['../classbeam.html#a0a94a8b318c3b6b7116be92fc9538670',1,'beam']]],
  ['makepressured',['makePressured',['../classbeam.html#aacefb413641c22db78ef146c0979ef4a',1,'beam']]],
  ['multiply',['multiply',['../class_quaternion.html#ac5a51b5d11022be5f17ab800898665cf',1,'Quaternion']]]
];
