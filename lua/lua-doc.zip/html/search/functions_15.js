var searchData=
[
  ['write',['write',['../class_file_pure.html#aed6091a0f974474b95a054d92e6d7bd3',1,'FilePure']]]
];
